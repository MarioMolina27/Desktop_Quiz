﻿#pragma once
class Calculator
{
public:
	int Add(int a, int b);
};

