# Header 1
## Header 2
### Header 3

Another Header
--------------

Yet Another Header
==================

- List 1
- List 2

1. Numbered list 1
2. Numbered list 2

```
code block no language
```

javascript code block:

```javascript
const constant = 100;
var message = "hello world " + constant.toString();
```

Inline `code block` here

Some **bold** and *italic* text

[Microsoft](https:///www.microsoft.com)
