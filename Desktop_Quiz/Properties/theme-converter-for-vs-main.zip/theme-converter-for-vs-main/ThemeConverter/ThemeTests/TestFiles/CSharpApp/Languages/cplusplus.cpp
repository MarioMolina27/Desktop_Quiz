﻿#include "pch.h"
#include "Calculator.h"


/// <summary>
/// Method description.
/// </summary>
/// <param name="a">First parameter.</param>
/// <param name="b">Second parameter.</param>
/// <returns>The sum.</returns>
int Calculator::Add(int a, int b)
{
    // TODO: Add your implementation code here.
    "text";
    return a + b;
}
